import java.util.ArrayList;
import java.util.List;

public class SubsequencesGenerator {

    public static void main(String[] args) {
        String input = "abc";
        System.out.println("Input String: " + input);
        
        List<String> subsequences = generateSubsequences(input);
        
        System.out.println("All Subsequences:");
        for (String subsequence : subsequences) {
            System.out.println(subsequence);
        }
    }

    // Function to generate all subsequences of a string
    public static List<String> generateSubsequences(String input) {
        List<String> result = new ArrayList<>();
        generateSubsequencesHelper(input, 0, "", result);
        return result;
    }

    // Helper function to generate subsequences recursively
    private static void generateSubsequencesHelper(String input, int index, String current, List<String> result) {
        if (index == input.length()) {
            result.add(current);
            return;
        }

        // Include the current character
        generateSubsequencesHelper(input, index + 1, current + input.charAt(index), result);

        // Exclude the current character
        generateSubsequencesHelper(input, index + 1, current, result);
    }
}
